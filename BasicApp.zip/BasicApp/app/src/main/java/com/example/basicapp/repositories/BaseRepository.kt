package com.example.basicapp.repositories

open class BaseRepository {

}