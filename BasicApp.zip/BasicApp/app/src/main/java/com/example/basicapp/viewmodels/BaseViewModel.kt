package com.example.basicapp.viewmodels

import androidx.lifecycle.ViewModel

open class BaseViewModel: ViewModel() {

}